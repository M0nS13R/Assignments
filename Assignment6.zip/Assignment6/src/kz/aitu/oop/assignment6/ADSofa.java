package kz.aitu.oop.assignment6;

public class ADSofa implements ISofa{
    @Override
    public void Legs() {
        System.out.println("ADSofa has 4 legs;");
    }

    @Override
    public void sitOn() {
        System.out.println("You can sit on ADSofa");
    }
}