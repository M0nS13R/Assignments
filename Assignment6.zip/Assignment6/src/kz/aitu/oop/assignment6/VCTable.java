package kz.aitu.oop.assignment6;

public class VCTable implements ICTable {
    @Override
    public void Legs() {
        System.out.println("VCTable has 4 legs;");
    }

    @Override
    public void sitOn() {
        System.out.println("You can't sit on VCTable");
    }
}