package kz.aitu.oop.assignment6;

public class MChair implements IChair {
    @Override
    public void Legs() {
        System.out.println("MChair without legs;");
    }

    @Override
    public void sitOn() {
        System.out.println("You can sit on MChair");
    }
}