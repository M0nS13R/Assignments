package kz.aitu.oop.assignment6;

public class MSofa implements ISofa {
    @Override
    public void Legs() {
        System.out.println("MSofa without legs;");
    }

    @Override
    public void sitOn() {
        System.out.println("You can sit on MSofa");
    }
}