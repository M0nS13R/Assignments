package kz.aitu.oop.assignment6;

public class ADCTable implements ICTable {
    @Override
    public void Legs() {
        System.out.println("ADCTable without legs;");
    }

    @Override
    public void sitOn() {
        System.out.println("You can't sit on ADCTable");
    }
}