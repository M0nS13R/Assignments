package kz.aitu.oop.assignment6;

public class MFFactory implements FAbsFactory{
    @Override
    public IChair createChair() {
        return new MChair();
    }

    @Override
    public ISofa createSofa() {
        return new MSofa();
    }

    @Override
    public ICTable createCoffeeTable() {
        return new MCTable();
    }
}