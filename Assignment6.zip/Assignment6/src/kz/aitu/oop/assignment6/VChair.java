package kz.aitu.oop.assignment6;

public class VChair implements IChair {
    @Override
    public void Legs() {
        System.out.println("VChairhas 4 legs;");
    }

    @Override
    public void sitOn() {
        System.out.println("You can sit on VChair");
    }
}
