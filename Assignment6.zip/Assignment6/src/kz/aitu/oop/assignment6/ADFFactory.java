package kz.aitu.oop.assignment6;

public class ADFFactory implements FAbsFactory{
    @Override
    public IChair createChair() {
        return new ADChair();
    }

    @Override
    public ISofa createSofa() {
        return new ADSofa();
    }

    @Override
    public ICTable createCoffeeTable() {
        return new ADCTable();
    }
}