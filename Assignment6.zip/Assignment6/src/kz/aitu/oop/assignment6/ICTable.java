package kz.aitu.oop.assignment6;

public interface ICTable {
    public void Legs();
    public void sitOn();
}