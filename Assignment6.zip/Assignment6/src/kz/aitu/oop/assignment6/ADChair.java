package kz.aitu.oop.assignment6;

public class ADChair implements IChair{
    @Override
    public void Legs() {
        System.out.println("ADChair has 4 legs;");
    }

    @Override
    public void sitOn() {
        System.out.println("You can sit on ADChair");
    }
}