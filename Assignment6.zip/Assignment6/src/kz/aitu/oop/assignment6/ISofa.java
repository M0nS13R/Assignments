package kz.aitu.oop.assignment6;

public interface ISofa {
    public void Legs();
    public void sitOn();
}