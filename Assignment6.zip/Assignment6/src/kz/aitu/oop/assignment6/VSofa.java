package kz.aitu.oop.assignment6;

public class VSofa implements ISofa {
    @Override
    public void Legs() {
        System.out.println("VSofa has 4 legs;");
    }

    @Override
    public void sitOn() {
        System.out.println("You can sit on VSofa");
    }
}
