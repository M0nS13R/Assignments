package kz.aitu.oop.assignment6;

public interface FAbsFactory {
    public IChair createChair();
    public ISofa createSofa();
    public ICTable createCoffeeTable();
}