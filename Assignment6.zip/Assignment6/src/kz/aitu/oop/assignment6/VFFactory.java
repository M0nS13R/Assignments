package kz.aitu.oop.assignment6;

public class VFFactory implements FAbsFactory{
    public IChair createChair() {
        return new VChair();
    }
    public ISofa createSofa() {
        return new VSofa();
    }
    public ICTable createCoffeeTable() {
        return new VCTable();
    }
}