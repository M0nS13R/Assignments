package kz.aitu.oop.assignment6;

public class Customer {
    public static void main (String[] args) {
        FAbsFactory FurAbsFact = new ADFFactory();
        IChair AChair = FurAbsFact.createChair();
        ISofa ASofa = FurAbsFact.createSofa();
        ICTable ACTable = FurAbsFact.createCoffeeTable();

        AChair.Legs();
        AChair.sitOn();

        ASofa.Legs();
        ASofa.sitOn();

        ACTable.Legs();
        ACTable.sitOn();
    }
}